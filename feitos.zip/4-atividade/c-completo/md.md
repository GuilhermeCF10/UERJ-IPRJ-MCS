## Análise de Estabilidade do Sistema de Controle

A estabilidade do sistema de controle foi avaliada utilizando o critério de Routh-Hurwitz. A função de transferência em malha fechada do sistema, dada por

\[ C(s)/R(s) = \frac{0.2}{0.5 + 0.92s + 1.3s^2 + s^3} \]

foi submetida à análise de Routh-Hurwitz para verificar a presença de condições de instabilidade. A matriz de Routh-Hurwitz obtida foi:

| s^3  | 1   |
|------|-----|
| s^2  | 1.3 |
| s^1  | 0.92|
| s^0  | 0.5 |

Importante notar que o valor zero encontrado na matriz (não mostrado acima) sugere que o sistema pode exibir oscilações não amortecidas. Isso indica que o sistema, sob as configurações atuais, não é estável. Recomenda-se revisar os parâmetros do controlador para alcançar a estabilidade desejada.

O código utilizado para a análise é mostrado abaixo:

```scilab
[stab, rh] = routh_t(C_R.den);
disp(rh);
